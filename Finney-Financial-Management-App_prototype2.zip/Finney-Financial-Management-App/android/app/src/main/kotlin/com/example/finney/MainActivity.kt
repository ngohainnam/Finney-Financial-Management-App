package com.example.finney

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
