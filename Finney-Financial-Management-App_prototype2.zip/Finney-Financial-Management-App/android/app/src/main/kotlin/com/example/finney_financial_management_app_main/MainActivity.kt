package com.example.finney_financial_management_app_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
