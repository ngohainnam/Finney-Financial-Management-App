class AppImages {
  
  static const String basePath = 'lib/shared/images/';
  
  static const String googleIcon = '${basePath}google_icon.png';
  static const String appLogo = '${basePath}app_logo.png';
}