class AppAnimations {
  static const String roboTyping = 'lib/shared/animations/robot_typing.json';
  static const String robotIdle = 'lib/shared/animations/robot_idle.json';
}