import 'package:flutter/material.dart';
import 'quiz_questions.dart';
import 'quiz_result.dart';
import 'quiz_model.dart';

class Quiz extends StatefulWidget {
  final List<QuizQuestion> questions;
  final String title;

  const Quiz({super.key, required this.questions, required this.title});

  @override
  State<Quiz> createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  int _currentIndex = 0;
  int _score = 0;

  void _answerQuestion(bool isCorrect) {
    if (isCorrect) _score++;

    if (_currentIndex < widget.questions.length - 1) {
      setState(() => _currentIndex++);
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => QuizResultPage(score: _score, total: widget.questions.length),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.questions[_currentIndex];

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              "Question ${_currentIndex + 1} of ${widget.questions.length}",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 20),
            Text(question.question, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 20),
            ...question.options.map((option) => ElevatedButton(
                  onPressed: () => _answerQuestion(option == question.correctAnswer),
                  child: Text(option),
                )),
          ],
        ),
      ),
    );
  }
}
