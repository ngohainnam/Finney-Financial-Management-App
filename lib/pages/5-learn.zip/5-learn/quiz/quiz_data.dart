final Map<String, List<Map<String, dynamic>>> quizData = {
  'how_to_use': [
    {
      'question': 'Where can you record an expense?',
      'options': ['Chatbot', 'Dashboard', 'Settings', 'Profile'],
      'answer': 'Dashboard',
    },
    {
      'question': 'What does the balance card show?',
      'options': ['Budget only', 'Spending tips', 'Total Balance', 'Goals'],
      'answer': 'Total Balance',
    },
    {
      'question': 'Where can you find visual spending charts?',
      'options': ['History tab', 'Dashboard', 'Learn tab', 'Chatbot'],
      'answer': 'Dashboard',
    },
    {
      'question': 'Which section helps in navigation help?',
      'options': ['Learn', 'Chatbot', 'Help icon', 'Profile'],
      'answer': 'Help icon',
    },
    {
      'question': 'Can you view previous expenses?',
      'options': ['No', 'Yes, in Reports', 'Only in Chatbot', 'Yes, in History'],
      'answer': 'Yes, in History',
    },
  ],

  'spending_tips': [
    {
      'question': 'What should you track to control spending?',
      'options': ['Wants', 'Savings', 'Needs', 'All of them'],
      'answer': 'All of them',
    },
    {
      'question': 'What is an example of a want?',
      'options': ['Rent', 'Groceries', 'Streaming Subscription', 'Transport'],
      'answer': 'Streaming Subscription',
    },
    {
      'question': 'Which is better: budgeting weekly or monthly?',
      'options': ['Weekly', 'Monthly', 'Both help', 'Neither'],
      'answer': 'Both help',
    },
    {
      'question': 'Why track your spending habits?',
      'options': ['For fun', 'To identify overspending', 'To show friends', 'None'],
      'answer': 'To identify overspending',
    },
    {
      'question': 'What is a smart way to avoid impulse buys?',
      'options': ['Buy immediately', 'Delay purchase', 'Ignore budgets', 'Shop daily'],
      'answer': 'Delay purchase',
    },
  ],
};
