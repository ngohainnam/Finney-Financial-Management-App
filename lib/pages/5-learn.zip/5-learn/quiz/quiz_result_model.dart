import 'package:hive/hive.dart';

part 'quiz_result_model.g.dart';

@HiveType(typeId: 3)
class QuizResult extends HiveObject {
  @HiveField(0)
  String lessonKey;

  @HiveField(1)
  int totalQuestions;

  @HiveField(2)
  int correctAnswers;

  @HiveField(3)
  DateTime dateTime;

  QuizResult({
    required this.lessonKey,
    required this.totalQuestions,
    required this.correctAnswers,
    required this.dateTime,
  });
}
