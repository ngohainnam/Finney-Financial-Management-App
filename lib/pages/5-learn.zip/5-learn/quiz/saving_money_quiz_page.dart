import 'package:flutter/material.dart';

class SavingMoneyQuizPage extends StatefulWidget {
  const SavingMoneyQuizPage({super.key});

  @override
  State<SavingMoneyQuizPage> createState() => _SavingMoneyQuizPageState();
}

class _SavingMoneyQuizPageState extends State<SavingMoneyQuizPage> {
  final List<Map<String, dynamic>> _questions = [
    {
      'question': 'Why is it important to save money?',
      'options': ['To waste it later', 'To prepare for future', 'To look rich', 'To spend faster'],
      'answer': 'To prepare for future'
    },
    {
      'question': 'What is a good habit for saving?',
      'options': ['Spending all income', 'Saving first', 'Waiting till month end', 'Ignoring savings'],
      'answer': 'Saving first'
    },
    {
      'question': 'What is an emergency fund?',
      'options': ['Loan money', 'Money for shopping', 'Backup savings', 'Reward points'],
      'answer': 'Backup savings'
    },
    {
      'question': 'Where should you keep saved money?',
      'options': ['In wallet', 'In safe at home', 'In a bank or app', 'With a friend'],
      'answer': 'In a bank or app'
    },
    {
      'question': 'Which one is a saving goal?',
      'options': ['Buy coffee', 'Emergency fund', 'Rent', 'Online shopping'],
      'answer': 'Emergency fund'
    },
  ];

  int _currentQuestion = 0;
  int _score = 0;
  bool _isFinished = false;

  void _answerQuestion(String selected) {
    if (selected == _questions[_currentQuestion]['answer']) {
      _score++;
    }

    if (_currentQuestion < _questions.length - 1) {
      setState(() => _currentQuestion++);
    } else {
      setState(() => _isFinished = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isFinished) {
      return Scaffold(
        appBar: AppBar(title: const Text("Quiz Result")),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("You scored $_score out of ${_questions.length}!",
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Back to Quizzes"),
              )
            ],
          ),
        ),
      );
    }

    final question = _questions[_currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: Text("Question ${_currentQuestion + 1}"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(question['question'],
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ...question['options'].map<Widget>((opt) => Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: const BorderSide(color: Colors.blueAccent),
                    ),
                    onPressed: () => _answerQuestion(opt),
                    child: Text(opt),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
