import 'package:flutter/material.dart';

class SimpleBudgetingQuizPage extends StatefulWidget {
  const SimpleBudgetingQuizPage({super.key});

  @override
  State<SimpleBudgetingQuizPage> createState() => _SimpleBudgetingQuizPageState();
}

class _SimpleBudgetingQuizPageState extends State<SimpleBudgetingQuizPage> {
  final List<Map<String, dynamic>> _questions = [
    {
      'question': 'What is a budget?',
      'options': ['Spending plan', 'Wish list', 'Bank account', 'Loan'],
      'answer': 'Spending plan'
    },
    {
      'question': 'Which item is typically fixed in a monthly budget?',
      'options': ['Snacks', 'Electric bill', 'Rent', 'Cinema tickets'],
      'answer': 'Rent'
    },
    {
      'question': 'Why should you budget?',
      'options': ['To impress friends', 'To track money', 'To spend more', 'To take loans'],
      'answer': 'To track money'
    },
    {
      'question': 'Best tool for managing a budget?',
      'options': ['Notebook', 'Mental notes', 'An app', 'None'],
      'answer': 'An app'
    },
    {
      'question': 'What should you do if you overspend?',
      'options': ['Ignore it', 'Adjust next month\'s budget', 'Spend more', 'Close your account'],
      'answer': 'Adjust next month\'s budget'
    },
  ];

  int _currentQuestion = 0;
  int _score = 0;
  bool _isFinished = false;

  void _answerQuestion(String selected) {
    if (selected == _questions[_currentQuestion]['answer']) {
      _score++;
    }

    if (_currentQuestion < _questions.length - 1) {
      setState(() => _currentQuestion++);
    } else {
      setState(() => _isFinished = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isFinished) {
      return Scaffold(
        appBar: AppBar(title: const Text("Quiz Result")),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("You scored $_score out of ${_questions.length}!",
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Back to Quizzes"),
              )
            ],
          ),
        ),
      );
    }

    final question = _questions[_currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: Text("Question ${_currentQuestion + 1}"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(question['question'],
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ...question['options'].map<Widget>((opt) => Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: const BorderSide(color: Colors.blueAccent),
                    ),
                    onPressed: () => _answerQuestion(opt),
                    child: Text(opt),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
