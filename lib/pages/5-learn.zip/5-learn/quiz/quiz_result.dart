import 'package:flutter/material.dart';

class QuizResultsPage extends StatelessWidget {
  const QuizResultsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // This page can be enhanced later to display stored scores using Hive.
    return Scaffold(
      appBar: AppBar(
        title: const Text("Your Quiz Results"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      backgroundColor: const Color(0xFFF5F7FB),
      body: const Center(
        child: Text(
          "Results feature coming soon!",
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      ),
    );
  }
}
