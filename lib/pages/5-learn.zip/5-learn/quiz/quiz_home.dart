import 'package:flutter/material.dart';
// import 'how_to_use_quiz.dart';
// import 'smart_spending_quiz.dart';
// import 'simple_budgeting_quiz.dart';
// import 'saving_money_quiz.dart';
// import 'quiz_results.dart';

class QuizHomePage extends StatelessWidget {
  const QuizHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FB),
        appBar: AppBar(
          title: const Text("Quiz Section"),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 1,
          bottom: const TabBar(
            isScrollable: true,
            labelColor: Colors.blueAccent,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blueAccent,
            tabs: [
              Tab(text: "How to Use"),
              Tab(text: "Smart Spending"),
              Tab(text: "Simple Budgeting"),
              Tab(text: "Saving Money"),
              Tab(text: "Results"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text("Coming Soon: How to Use Quiz")),
            Center(child: Text("Coming Soon: Smart Spending Quiz")),
            Center(child: Text("Coming Soon: Simple Budgeting Quiz")),
            Center(child: Text("Coming Soon: Saving Money Quiz")),
            Center(child: Text("Quiz Results Placeholder")),
          ],
        ),
      ),
    );
  }
}
