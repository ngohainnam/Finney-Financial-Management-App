import 'package:flutter/material.dart';
import 'how_to_use_quiz_page.dart';
import 'smart_spending_quiz_page.dart';
import 'simple_budgeting_quiz_page.dart';
import 'saving_money_quiz_page.dart';
import 'quiz_results_page.dart';

class QuizSectionPage extends StatelessWidget {
  const QuizSectionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Quiz Section'),
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.blueAccent,
          bottom: const TabBar(
            isScrollable: true,
            labelColor: Colors.blueAccent,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blueAccent,
            tabs: [
              Tab(text: 'How to Use'),
              Tab(text: 'Smart Spending'),
              Tab(text: 'Budgeting'),
              Tab(text: 'Saving Money'),
              Tab(text: 'Results'),
            ],
          ),
        ),
        backgroundColor: const Color(0xFFF5F7FB),
        body: const TabBarView(
          children: [
            HowToUseQuizPage(),
            SmartSpendingQuizPage(),
            SimpleBudgetingQuizPage(),
            SavingMoneyQuizPage(),
            QuizResultsPage(),
          ],
        ),
      ),
    );
  }
}
