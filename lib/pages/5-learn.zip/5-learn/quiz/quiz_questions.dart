import 'quiz_model.dart';

final List<QuizQuestion> howToUseAppQuestions = [
  QuizQuestion(
    question: "What feature lets you view past expenses?",
    options: ["History", "Dashboard", "AI Chatbot", "Learn"],
    correctAnswer: "History",
  ),
  // Add 4 more
];

final List<QuizQuestion> smartSpendingQuestions = [
  QuizQuestion(
    question: "What is a smart spending habit?",
    options: ["Impulse buying", "Budgeting", "Skipping bills", "Maxing credit"],
    correctAnswer: "Budgeting",
  ),
  // Add 4 more
];

final List<QuizQuestion> simpleBudgetingQuestions = [
  QuizQuestion(
    question: "What should be included in a budget?",
    options: ["Only income", "Only fun money", "Income and expenses", "Just rent"],
    correctAnswer: "Income and expenses",
  ),
  // Add 4 more
];

final List<QuizQuestion> savingMoneyQuestions = [
  QuizQuestion(
    question: "What helps save money effectively?",
    options: ["Spending often", "Avoiding sales", "Setting goals", "Using cash always"],
    correctAnswer: "Setting goals",
  ),
  // Add 4 more
];
