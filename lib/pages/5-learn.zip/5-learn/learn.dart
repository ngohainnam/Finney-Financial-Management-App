import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:finney/pages/5-learn/how_to_use_app.dart';
import 'package:finney/pages/5-learn/smart_spending_tips.dart';
import 'package:finney/pages/5-learn/simple_budgeting.dart';
import 'package:finney/pages/5-learn/saving_money_easy.dart';
import 'package:finney/pages/5-learn/learn_progress.dart';
// IMPORTANT: fix the import below to reference your real file path:
import 'package:finney/pages/5-learn/quiz/quiz_section_page.dart'; // <-- Must match your actual file location

class Learn extends StatefulWidget {
  const Learn({Key? key}) : super(key: key);

  @override
  State<Learn> createState() => _LearnState();
}

class _LearnState extends State<Learn> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedTab = 'All';

  final List<Map<String, dynamic>> _lessons = [
    {
      'title': 'How to Use the App',
      'icon': LucideIcons.smartphone,
      'color': const Color(0xFFE3F2FD),
      'subtitle': 'Start here',
      'lessonKey': 'how_to_use_app',
      'totalVideos': 3,
      'page': const HowToUseApp(),
    },
    {
      'title': 'Smart Spending Tips',
      'icon': LucideIcons.badgeDollarSign,
      'color': const Color(0xFFB3E5FC),
      'subtitle': 'Spend smarter, live better',
      'lessonKey': 'smart_spending_tips',
      'totalVideos': 2,
      'page': const SmartSpendingTips(),
    },
    {
      'title': 'Simple Budgeting',
      'icon': LucideIcons.layoutDashboard,
      'color': const Color(0xFFD1C4E9),
      'subtitle': 'Plan with ease',
      'lessonKey': 'simple_budgeting',
      'totalVideos': 2,
      'page': const SimpleBudgeting(),
    },
    {
      'title': 'Saving Money Easy',
      'icon': LucideIcons.piggyBank,
      'color': const Color(0xFFE1D5F0),
      'subtitle': 'Build your future',
      'lessonKey': 'saving_money_easy',
      'totalVideos': 2,
      'page': const SavingMoneyEasy(),
    },
  ];

  // This quiz item is displayed only when the "Quiz" tab is selected
  final Map<String, dynamic> _quizItem = {
    'title': 'Take the Quiz',
    'icon': LucideIcons.bookOpen,
    'color': const Color(0xFFFFF3E0),
    'subtitle': 'Test your knowledge',
    'lessonKey': 'quiz_section',
    'totalVideos': 0,
    // IMPORTANT: This must match the class name in your quiz_section_page.dart
    'page': const QuizSectionPage(),
  };

  @override
  void initState() {
    super.initState();
    _updateLessonStatuses();
  }

  void _updateLessonStatuses() {
    for (var lesson in _lessons) {
      final completed = LearnProgress.getCompletedCount(
        lesson['lessonKey'],
        lesson['totalVideos'],
      );
      final isDone = LearnProgress.isLessonCompleted(
        lesson['lessonKey'],
        lesson['totalVideos'],
      );
      lesson['progress'] = completed / lesson['totalVideos'];
      lesson['status'] = isDone
          ? 'completed'
          : (completed > 0 ? 'ongoing' : 'all');
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isQuizTab = _selectedTab == 'Quiz';

    // If "Quiz" tab is selected, show only the quiz tile. Otherwise, show normal lessons filtered by tab.
    final List<Map<String, dynamic>> filteredList = isQuizTab
        ? [_quizItem]
        : _lessons.where((item) {
            final searchText = _searchController.text.toLowerCase();
            final matchesSearch = item['title'].toLowerCase().contains(searchText);
            final matchesTab = _selectedTab == 'All'
                ? true
                : _selectedTab.toLowerCase() == item['status'];
            return matchesSearch && matchesTab;
          }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'LearningHub',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: Colors.blueAccent,
          ),
        ),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
        child: Column(
          children: [
            // Tab row: All, Ongoing, Completed, Quiz
            Row(
              children: [
                _buildTab('All'),
                _buildTab('Ongoing'),
                _buildTab('Completed'),
                _buildTab('Quiz'),
              ],
            ),
            const SizedBox(height: 16),
            _buildSearchBar(),
            const SizedBox(height: 16),
            Expanded(
              child: filteredList.isEmpty
                  ? const Center(child: Text('No results found.'))
                  : ListView.separated(
                      itemCount: filteredList.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 16),
                      itemBuilder: (context, index) {
                        final item = filteredList[index];
                        return GestureDetector(
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => item['page']),
                            );
                            setState(() {
                              _updateLessonStatuses();
                            });
                          },
                          child: _buildLessonCard(
                            title: item['title'],
                            icon: item['icon'],
                            backgroundColor: item['color'],
                            subtitle: item['subtitle'],
                            progress: item['progress'] ?? 0.0,
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label) {
    final bool isActive = _selectedTab == label;
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () => setState(() => _selectedTab = label),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isActive ? Colors.blueAccent : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: isActive ? Colors.white : Colors.grey,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(0, 2),
          )
        ],
      ),
      child: TextField(
        controller: _searchController,
        onChanged: (_) => setState(() {}),
        decoration: const InputDecoration(
          icon: Icon(Icons.search),
          hintText: 'Search for topics...',
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _buildLessonCard({
    required String title,
    required IconData icon,
    required Color backgroundColor,
    required String subtitle,
    required double progress,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            offset: Offset(0, 3),
          )
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, size: 36, color: Colors.black87),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
                if (subtitle.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                if (progress > 0.0)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: LinearProgressIndicator(
                      value: progress,
                      backgroundColor: Colors.white54,
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                    ),
                  ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
        ],
      ),
    );
  }
}
